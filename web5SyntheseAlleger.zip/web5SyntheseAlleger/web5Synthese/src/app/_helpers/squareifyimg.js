import scaleCropRotate, { blobToImageData, imageDataToBlob } from "scale-crop-rotate";

  export const imageResizeAndSquareCrop = async (file, maxSize, newName) => {
    const imgData = await blobToImageData(file);
    const minSize = Math.min(imgData.width, imgData.height);
    const rectangle = {
      left: (imgData.width - minSize) / 2,
      top: (imgData.height - minSize) / 2,
      width: Math.min(minSize, maxSize),
      height: Math.min(minSize, maxSize),
    };
    const resultData = await scaleCropRotate(
      imgData,
      rectangle.width,
      rectangle.height,
      rectangle.left,
      rectangle.top,
      minSize,
      minSize
    );
    const blob = await imageDataToBlob(resultData);
    return new File([blob], newName);
  };