import { createClient } from '@/app/_lib/supabase/server';
import FormBanUser from '../_components/FormBanUser';
import FormBanQuiz from '../_components/FormBanQuiz';
import Link from 'next/link';
import { redirect } from 'next/dist/server/api-utils';

const SiteAdmin = async () => {
  const supabase = createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { data: profile } = await supabase
    .from('profiles')
    .select()
    .eq('id', user.id)
    .single();

  if(profile.is_admin == false)
  {
    redirect('/site');
  }

  const { data: quizzes } = await supabase
    .from('quizzes')
    .select();

  const { data: profiles } = await supabase
    .from('profiles')
    .select();

  return (
    <div>
        <Link href="/site">
            <p>Back to quiz list</p>
        </Link>
        <br /><br />
      <h1>Admin page</h1>
      <br /><br />

      <div>
        <h2>Ban user</h2>
        <ul>
          {profiles.map(({ id, username, is_banned, is_admin, desc_banned }) => (
              <div key={id}>
              <FormBanUser
                userId={id}
                username={username}
                initialIsBanned={is_banned}
                initialIsAdmin={is_admin}
                initialDescBanned={desc_banned}
                />
              <br />
            </div>
          ))}
        </ul>
    </div>

    <div>
        <h2>Ban quiz</h2>
        <ul>
          {quizzes.map(({ id, title, is_banned, desc_banned }) => (
            <div key={id}>
              <FormBanQuiz
                quizId={id}
                title={title}
                initialIsBanned={is_banned}
                initialDescBanned={desc_banned}
              />
              <br />
            </div>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default SiteAdmin;
