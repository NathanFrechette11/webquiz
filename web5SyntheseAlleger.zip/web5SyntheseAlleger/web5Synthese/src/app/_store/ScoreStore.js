import { create } from "zustand";

export const useScoreStore = create((set) => {
    return{
        currentScore: 0,
        totalQuestions: 0,
        setScore: (currentScore) => set({ currentScore }),
        setTotalQuestions: (totalQuestions) => set({ totalQuestions }),
        resetScore: () => set({ currentScore: 0, totalQuestions: 0 }),
    }
});
 