'use server'
import { revalidatePath } from "next/cache";
import { createClient } from "../_lib/supabase/server";


export const ShareQuizAction = async ({ email, username, quizId, isEmail }) => {
    const supabase = createClient();
    const user = isEmail ? await getUserByEmail({ email }) : await getUserByUsername({ username });
    
    if (!user) {
        console.error("User not found.");
        return;
    }
    
    const { data, error } = await supabase.from('quizzes_sharedUsers').upsert({
        quiz_id: quizId,
        user_id: user.id
    });
    
    if (error) {
        console.error("Error sharing quiz:", error);
        return;
    } else {
        console.log("Quiz shared successfully:", data);
    }
    revalidatePath(`quiz/${quizId}`, "page");
    return data;
};

const getUserByEmail = async ({ email }) => {
    const supabase = createClient();
    const { data, error } = await supabase.from('profiles').select('id').eq('email', email).single();
    if (error || !data) {
        console.error("Error fetching user by email:", error);
        return null;
    }
    console.log("User fetched by email successfully:", data);
    return data; // This is the user object containing the `id`
};

const getUserByUsername = async ({ username }) => {
    const supabase = createClient();
    const { data, error } = await supabase.from('profiles').select('id').eq('username', username).single();
    if (error || !data) {
        console.error("Error fetching user by username:", error);
        return null;
    }
    console.log("User fetched by username successfully:", data);
    return data; // This is the user object containing the `id`
};

export const getSharedUsers = async (quizId) => {
    const supabase = createClient();
    // Detailed logging and debugging
    console.log("Attempting to fetch shared users for quizId:", quizId);
    
    const { data: sharedUsersData, error: sharedUsersError } = await supabase
    .from('quizzes_sharedUsers')
    .select('user_id') 
    .eq('quiz_id', quizId);
    
    console.log("Raw fetch result:", {
        data: sharedUsersData,
        error: sharedUsersError
    });
    
    if (sharedUsersError) {
        console.error("Error fetching shared users:", sharedUsersError);
        return null;
    }
    
    return sharedUsersData;
};

export const removeSharedUser = async ( quizId, userId ) => {
    const supabase = createClient();
    console.log('Removing shared user:', userId, 'from quiz:', quizId);
    const { data, error } = await supabase
    .from('quizzes_sharedUsers')
    .delete()
    .eq('quiz_id', quizId)
    .eq('user_id', userId);
    
    if (error) {
        console.error("Error removing shared user:", error);
        return null;
    }
    const newPath = `quiz/${quizId}`;
    revalidatePath(newPath, "page");
    return data;
};
