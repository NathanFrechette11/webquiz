// pages/api/files.js
'use server';

import { UTApi } from "uploadthing/server";

export const getFilesAction = async (req, res) => {
    const token = process.env.UPLOADTHING_TOKEN;
    const utApi = req.utApi || new UTApi({ token: token });

    try {
        const response = await utApi.listFiles({ limit: 10, offset: 0 });
        res.status(200).json({ files: response.files });
    } catch (error) {
        console.error("Error fetching files:", error);
        res.status(500).json({ error: error.message });
    }
};
