'use server'
import { revalidatePath } from "next/cache";
import { createClient } from "../_lib/supabase/client";
import { redirect } from "next/navigation";

export const CreateQuiz = async (quizData, questions, userId) => {
  const supabase = createClient();

  const {
      data: { user },
    } = await supabase.auth.getUser();
  
    const { data: profile } = await supabase
      .from("profiles")
      .select()
      .eq("id", user.id)
      .single();
  
    if (profile.is_banned) {
      redirect(`/banned`);
    }

  console.log("action quizdata", quizData, "userId", userId);
  const { data: quiz, error: quizError } = await supabase
    .from("quizzes")
    .upsert([
      {
        title: quizData.title,
        description: quizData.description,
        category: quizData.category,
        image: quizData.image,
        isPrivate: quizData.isPrivate,
        created_by: userId,
      },
    ])
    .select("id")
    .single();

  if (quizError) {
    console.error("Error inserting quiz:", quizError);
    return;
  }

  console.log("questions", questions);
  
  for (const question of questions) {
    let questionInsert = {
      quiz_id: quiz.id,
      title: question.questionText,
      type: question.questionType,
    };

    switch (question.questionType) {
      case "number":
        questionInsert.options = JSON.stringify({
          value: question.numberAnswer || 0,
        });
        break;
      case "true_false":
      case "multiple_choice":
      case "one_choice":
        questionInsert.options = JSON.stringify(
          question.answers.map((answer) => ({
            text: answer.text,
            isCorrect: answer.isCorrect,
          }))
        );
        break;
      case "ordering":
        questionInsert.options = JSON.stringify(
          question.answers.map((answer, i) => ({
            text: answer.text,
            order: i,
          }))
        );
        break;
      case "matching":
        questionInsert.options = JSON.stringify(
          question.answers.map((answer, i) => ({
            [`a${i}`]: answer.columnA,
            [`b${i}`]: answer.columnB,
          }))
        );
        break;
      default:
        console.error("Unknown question type:", question.questionType);
        return;
    }

    try {
      const { data: questionData, error: questionError } = await supabase
        .from("questions")
        .upsert(questionInsert)
        .single();

        console.log("creationdata", questionInsert)

      if (questionError) {
        console.error("Error inserting question:", questionError);
        return;
      }

      console.log("Question inserted successfully:", questionData);
    } catch (error) {
      console.error("Unexpected error inserting question:", error);
    }
  }

  revalidatePath("/quiz/create");
  console.log("Quiz and questions saved successfully!");
};
