"use server";
import { createClient } from "@/app/_lib/supabase/server";
import { redirect } from "next/navigation";
import { QUIZ_PER_PAGE } from "../_constants/quiz";


export const chercherQuiz = async (start) => {
  const nbResults = QUIZ_PER_PAGE;
  const supabase = createClient();

  const {data, error} = await supabase.from('quizzes').select().neq('is_banned', true).range(start, start + nbResults);
  console.log(error);
  return data;
};

export const chercherQuizParId = async (quiz_id) => {
  const supabase = createClient();

  const { data: quizData, error: quizError } = await supabase
    .from('chercherquizcategorieetquestions')
    .select("*")
    .eq("quizid", quiz_id);

  const { data: attempts, error: attemptsError, count: attempsCount } = await supabase
    .from('attempts')
    .select("*", {count: 'exact'})
    .eq("quiz_id", quiz_id);

    // if (!/^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/.test(quiz_id)) {
    //   throw new Error(`Invalid quiz_id: ${quiz_id}`);
    // }
    

  if (quizError || attemptsError) {
    // Handle the errors properly, for example, by throwing them or logging
    throw new Error(`Failed to fetch data: ${quizError?.message || ''} ${attemptsError?.message || ''}`);
  }

  return { quizData, attempts, attempsCount };
};

export const recherche = (formData) => {

  const query = formData.get("recherche");

  if (!query) {
    redirect("/site");
  }

  redirect(`/search?q=` + query);
};

export const chercherQuizParTitre = async ({searchParams}) => {
  const supabase = createClient();

  const {data, error} = await supabase.from('quizzes').select().ilike("quiztitle", `%${searchParams}%`);

  return data;
};

export const chercherUser = async () => {
  const supabase = createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  return user;
};