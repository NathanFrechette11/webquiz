"use server";
import { createClient } from "@/app/_lib/supabase/server";
import { redirect } from "next/navigation";
import { updateOrCreateAttempt } from "./handleQuizSubmit";

export const validerReponses = async (formData) => {
  // const { formData } = allData;
  // const quiz_id = allData.quiz_id;
  const supabase = createClient();
  // const totalBonneReponses = allData.totalBonneReponses;
  const totalBonneReponses = formData.get("totalBonneReponses");
  const quiz_id = formData.get("quiz_id");
  const entries = formData.entries();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { data: profile } = await supabase
    .from("profiles")
    .select()
    .eq("id", user.id)
    .single();
  
    if (profile.is_banned) {
      redirect(`/banned`);
    }

  let score = 0;

  const reponsesParQuestion = {};

  for (let [question, reponseUtilisateur] of entries) {
    if (question.startsWith("question_")) {
      const questionId = question.split("_")[1];
      if (!reponsesParQuestion[questionId]) {
        reponsesParQuestion[questionId] = [];
      }
      reponsesParQuestion[questionId].push(reponseUtilisateur);
    }
  }

  for (const questionId in reponsesParQuestion) {
    const reponsesUtilisateur = reponsesParQuestion[questionId];
    let contientMauvaiseReponse = false;
    let pointsQuestion = 0;

    const { data: questionData } = await supabase
      .from("questions")
      .select("options")
      .eq("id", questionId)
      .single();

    const options = JSON.parse(questionData.options);
    for (const reponse of reponsesUtilisateur) {
      if (reponse === "true") {
        pointsQuestion++;
      } else if (reponse === options.value) {
        pointsQuestion++;
      } else if (reponse === "false") {
        contientMauvaiseReponse = true;
        break;
      }
    }

    if (contientMauvaiseReponse) {
      pointsQuestion = 0;
    }

    score += pointsQuestion;
  }

  let matchingScore;

  if (formData.get("score")) {
    matchingScore = parseInt(formData.get("score"));
  }

  if (matchingScore != null) {
    score += matchingScore;
  }
  let orderingScore;

  if (formData.get("scoreOrdering")) {
    orderingScore = parseInt(formData.get("scoreOrdering"));
  }

  if (orderingScore != null) {
    score += orderingScore;
  }

  const pourcentage = Math.round((score / totalBonneReponses) * 100);

  const { data: quiz, error } = await supabase
    .from("quizzes")
    .select("scores")
    .select("title")
    .eq("id", quiz_id)
    .single();

  if (error) {
    console.error("Erreur lors de la récupération du quiz:", error);
    return { error: "Erreur lors de la récupération du quiz" };
  }

  const scores = quiz.scores || [];

  scores.push(pourcentage);

  const totalScores = scores.reduce((acc, score) => acc + score, 0);

  const moyenne = totalScores / scores.length;

  const moyenneArrondie = Math.round(moyenne);

  const { error: updateError } = await supabase
    .from("quizzes")
    .update({
      scores: scores,
      point_avg: moyenneArrondie,
    })
    .eq("id", quiz_id);

  console.log("pourcentage valide", pourcentage);

  const { data: ProfileQuiz, error: profileQuizError } = await supabase
    .from('quizcompletedbyprofiles')
    .select()
    .eq('id_quiz', quiz_id)
    .eq('id_profile', profile.id)
    .single();

  if(ProfileQuiz)
  {
    const { error: updateErrorProfileQuiz } = await supabase
    .from('quizcompletedbyprofiles')
    .update({
      score: pourcentage
    })
    .eq('id_quiz', quiz_id)
    .eq('id_profile', profile.id);

    if (updateErrorProfileQuiz) {
      console.error("Erreur lors de la mise à jour du score dans quizcompletedbyprofiles:", updateErrorProfileQuiz.message);
    }
  }
  else
  {
    const { error: insertErrorProfileQuiz } = await supabase
    .from("quizcompletedbyprofiles")
    .insert({
      score: pourcentage,
      id_quiz: quiz_id,
      quiz_title: quiz.title,
      id_profile: profile.id
    });

    if (insertErrorProfileQuiz) {
      console.error("Erreur lors de l'insertion dans quizcompletedbyprofiles:", insertErrorProfileQuiz.message);
  }
}

  const attemptData = {
    quiz_id: quiz_id,
    userId: user.id, 
    totalCorrect: score,
    totalQuestions: parseInt(totalBonneReponses),
    percentage: pourcentage,
  };

  const attempt = await updateOrCreateAttempt(attemptData);

  if (updateError) {
    console.error("Erreur lors de la mise à jour du score:", updateError);
    return { error: "Erreur lors de la mise à jour du score" };
  }

  redirect(`/quiz/score/${pourcentage}`);
};
