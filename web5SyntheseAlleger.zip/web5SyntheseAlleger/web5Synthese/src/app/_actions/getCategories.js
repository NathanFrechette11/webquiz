'use server'
const { createClient } = require("../_lib/supabase/server");

export const fetchCategories = async () => {
    const supabase = createClient();
    const { data: categories, error } = await supabase.from('categories').select('*');
    return categories;
};