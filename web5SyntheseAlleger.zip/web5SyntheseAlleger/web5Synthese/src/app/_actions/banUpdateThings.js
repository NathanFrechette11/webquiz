"use server";
import { createClient } from "@/app/_lib/supabase/server";
import { redirect } from "next/navigation";

export const BanUser = async (formData) => {

  const user_id = formData.get('user_id');
  const isBanned = formData.get('isBanned');
  const isAdmin = formData.get('isAdmin');
  let descBan = formData.get('descBan');

  if(descBan == null || descBan == "")
  {
    descBan = null;
  }

  const supabase = createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { data: profile } = await supabase
    .from('profiles')
    .select()
    .eq('id', user.id)
    .single();

  if(profile?.is_admin)
  {
    const { error: updateError } = await supabase
      .from('profiles')
      .update({
        is_banned: isBanned,
        is_admin: isAdmin,
        desc_banned: descBan
      })
      .eq('id', user_id);

      if (updateError) {
        console.error('Erreur lors de la mise à jour du profile:', updateError);
        return new Response('Erreur lors de la mise à jour du profile', { status: 500 });
      }
  }

  redirect(`/admin`);
};

export const BanQuiz = async (formData) => {

  const quiz_id = formData.get('quiz_id');
  const isBanned = formData.get('isBanned');
  let descBan = formData.get('descBan');

  if(descBan == null || descBan == "")
  {
    descBan = null;
  }

  const supabase = createClient();

  const { error: updateError } = await supabase
    .from('quizzes')
    .update({
      is_banned: isBanned,
      desc_banned: descBan
    })
    .eq('id', quiz_id);

  if (updateError) {
    console.error('Erreur lors de la mise à jour du quiz:', updateError);
    return new Response('Erreur lors de la mise à jour du quiz', { status: 500 });
  }

  redirect(`/admin`);
};