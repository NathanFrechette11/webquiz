"use server";
import { createClient } from "@/app/_lib/supabase/server";

export const updateOrCreateAttempt = async ({ quiz_id, userId, totalCorrect, totalQuestions, percentage }) => {
  const supabase = createClient();

  console.log("Mise à jour de la tentative :", { quiz_id, userId, totalCorrect, totalQuestions });

  const { data, error } = await supabase
    .from('attempts')
    .upsert({
      quiz_id: quiz_id,
      percentage: percentage,
      user_id: userId,
      score: totalCorrect,
    })
    .select();

  if (error) {
    console.error("Erreur lors de la mise à jour de l'`attempt` :", error.message);
    throw new Error(error.message);
  }
  console.log("Nouvelle tentative :", data[0]);
  return data[0];
};
