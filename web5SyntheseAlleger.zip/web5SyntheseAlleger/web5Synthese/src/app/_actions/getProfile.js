'use server'
import { createClient } from "../_lib/supabase/server"

export const selectProfileAction = async (uid) => {
    const supabase = createClient();
    const profile = await supabase.from('profiles').select().eq('id', uid).single();
    console.log("profile", profile);
    return profile;
}

export const getUserAchievements = async (uid) => {
    const supabase = createClient();
    const achievements = await supabase.from('achievements_progress').select('*, achievements(*)').eq('user_id', uid);
    return achievements;
}

export const getAllAchievements = async () => {
    const supabase = createClient();
    const achievements = await supabase.from('achievements').select("*");
    return achievements;
}