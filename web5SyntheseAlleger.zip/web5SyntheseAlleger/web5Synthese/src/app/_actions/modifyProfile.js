"use server";
import { revalidatePath } from "next/cache";
import { createClient } from "../_lib/supabase/server";
import { redirect } from "next/navigation";

export const modifyAvatar = async (avatarUrl, userId) => {
    console.log('yippee',userId);
  const supabase = createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { data: profile } = await supabase
    .from("profiles")
    .select()
    .eq("id", user.id)
    .single();

  if (profile.is_banned) {
    redirect(`/banned`);
  }

  const result = await supabase
    .from("profiles")
    .update({ avatar: avatarUrl })
    .eq("id", userId);
  revalidatePath("/profile");
};
export const modifyUsername = async (username, userId) => {
  const supabase = createClient();
  
  const result = await supabase
  .from("profiles")
  .update({ username: username })
  .eq("id", userId);
  console.log('yippee',result);
  revalidatePath("/profile");
};
