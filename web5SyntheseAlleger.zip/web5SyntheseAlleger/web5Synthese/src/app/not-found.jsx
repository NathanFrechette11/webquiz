import React from "react";
import styles from "./notfoundLoading.module.css";
import Link from "next/link";

const NotFound = () => {
  return (
    <div className={styles.notFound__Container}>
      <h1 className={styles.notFound__title}>404</h1>
      <p className={styles.notFound__description}>Oops! Page not found.</p>
      <Link href="/" className={styles.button}>
        Go Back Home
      </Link>
    </div>
  );
};

export default NotFound;
