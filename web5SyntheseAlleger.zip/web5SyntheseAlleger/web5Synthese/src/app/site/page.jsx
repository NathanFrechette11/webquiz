import Link from 'next/link';
import { QUIZ_PER_PAGE } from '../_constants/quiz';
import { recherche } from '../_actions/chercherElement';
import ListeQuiz from '../_components/ListeQuiz';
import { redirect } from 'next/navigation';
import { createClient } from '../_lib/supabase/server';
import styles from './page.module.css';
import QuizUiCard from '../_components/QuizUiCard';

const Site = async () => {
  const supabase = createClient();

  const VerifierAdmin = () => {
    if (profile?.is_admin) {
      return (
        <Link href="/admin">
          Go to Admin page
        </Link>
      );
    }
  };

  const { data: quizzes } = await supabase
    .from('quizzes')
    .select()
    .neq('is_banned', true)
    .range(0, QUIZ_PER_PAGE - 1);

  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { data: profile } = await supabase
    .from('profiles')
    .select()
    .eq('id', user.id)
    .single();

  if(profile.is_banned)
  {
    redirect(`/banned`);
  }

  const AfficherQuizUser = async () => {
    const { data: quizzesUser } = await supabase
      .from('quizzes')
      .select()
      .eq('created_by', user.id);

    if (!quizzesUser) return null;

    return (
      <div className={styles.quizList}>
        {quizzesUser.map((quiz) => (
          <div key={quiz.id}>
            <QuizUiCard quiz={quiz} />
          </div>
        ))}
      </div>
    );
    }

  return (
    <div className={styles.site}>
      {VerifierAdmin()}
      <form action={recherche} className={styles.search}>
        <input type="text" name="recherche" className={styles.search__input}/>
        <button type="submit" className={styles.search__button}>Search 🔍</button>
      </form>
      <h1 className={styles.site__title}>Your quizzes</h1>
      {AfficherQuizUser()}
      <div className={styles.site__allquizzes}>
        <h1 className={styles.site__title}>All quizzes</h1>
        <ul className={styles.quizList}>
            <ListeQuiz
              quizzesInitial={quizzes}
            />
          </ul>
      </div>
    </div>
  )
};

export default Site;

