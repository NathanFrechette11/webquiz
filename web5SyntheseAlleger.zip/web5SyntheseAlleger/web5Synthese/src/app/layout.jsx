import localFont from "next/font/local";
import "./globals.css";
import Link from "next/link";
import { createClient } from "./_lib/supabase/server";
import Header from "./_components/HeaderFooter/Header";
import Footer from "./_components/HeaderFooter/Footer";

const geistSans = localFont({
  src: "./fonts/GeistVF.woff",
  variable: "--font-geist-sans",
  weight: "100 900",
});
const geistMono = localFont({
  src: "./fonts/GeistMonoVF.woff",
  variable: "--font-geist-mono",
  weight: "100 900",
});

export const metadata = {
  title: "The best quiz game ever",
  description: "We do some cool quizzes",
};

export default async function RootLayout({ children }) {
  const supabase = createClient();

  // Use a server-side call to fetch the current user.
  const {
    data: { user }
  } = await supabase.auth.getUser();

  return (
    <html lang="en">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        <div>
          {!user ? (
            <> </>
          ) : (
            <>
              <Header />
            </>
          )}
        </div>
        {children}
        {/* <Footer /> */}
      </body>
    </html>
  );
}
