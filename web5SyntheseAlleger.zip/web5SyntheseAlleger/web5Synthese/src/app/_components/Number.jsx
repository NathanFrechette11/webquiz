import styles from "./PlayQuiz.module.css";

const Number = ({ questionid, questiontitle, questionimg, optionsArray }) => {
  console.log("Props reçues dans Number :", { questionid, questiontitle, questionimg, optionsArray });
  return (
    <div key={questionid} className={styles.Question}>
      {questionimg && <img src={questionimg} alt={questiontitle} />}
      <h3 className={styles.Question__title}>{questiontitle}</h3>
      <label className={styles.Question__choice}>
        <input type="number" name={`question_${questionid}`} 
        placeholder="Enter your answer"
        className={styles.nb__input}/>
      </label>
    </div>
  )
}

export default Number