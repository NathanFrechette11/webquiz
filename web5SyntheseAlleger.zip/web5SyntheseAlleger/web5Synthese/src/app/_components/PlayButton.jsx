import React from "react";
import styles from "./PlayButton.module.css"; // Importation du fichier CSS

const PlayButton = ({ props }) => {
  return (
    <button className={styles.playButton}>
      <span className={styles.playButton__icon}>►</span> {props}
    </button>
  );
};

export default PlayButton;
