"use client";

import { useState, useEffect } from "react";
import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd";
import styles from "./PlayQuiz.module.css";

const Matching = ({
  questionid,
  questiontitle,
  questionimg,
  optionsArray,
  envoyerFormulaire,
}) => {
  const [choicesA, setChoicesA] = useState([]);
  const [choicesB, setChoicesB] = useState([]);
  const [allChoices, setAllChoices] = useState([]);
  const [isLoaded, setIsLoaded] = useState(false);
  const [score, setScore] = useState(0);

  const shuffleArray = (array) => {
    let shuffledArray = [...array];
    for (let i = shuffledArray.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffledArray[i], shuffledArray[j]] = [
        shuffledArray[j],
        shuffledArray[i],
      ];
    }
    return shuffledArray;
  };

  useEffect(() => {
    if (optionsArray && optionsArray.length > 0) {
      const allOptions = optionsArray.reduce((acc, option) => {
        if (option.columnA && option.columnB) {
          acc.push({ value: option.columnA, board: "A" });
          acc.push({ value: option.columnB, board: "B" });
        }
        return acc;
      }, []);

      const shuffledChoices = shuffleArray(allOptions);

      setAllChoices(shuffledChoices);
      setChoicesA([]);
      setChoicesB([]);
      setIsLoaded(true);
    } else {
      console.error("optionsArray est vide ou mal formaté !");
    }
  }, [optionsArray]);

  const handleDragEnd = (result) => {
    const { source, destination } = result;

    if (!destination) return;

    const getList = (id) => {
      if (id === "allChoices") return [...allChoices];
      if (id === "A") return [...choicesA];
      if (id === "B") return [...choicesB];
    };

    const updateList = (id, updatedList) => {
      if (id === "allChoices") setAllChoices(updatedList);
      if (id === "A") setChoicesA(updatedList);
      if (id === "B") setChoicesB(updatedList);
    };

    if (
      source.droppableId === destination.droppableId &&
      source.index === destination.index
    ) {
      return;
    }

    if (source.droppableId === destination.droppableId) {
      const updatedList = getList(source.droppableId);
      const [movedItem] = updatedList.splice(source.index, 1);
      updatedList.splice(destination.index, 0, movedItem);
      updateList(source.droppableId, updatedList);
      return;
    }

    const sourceList = getList(source.droppableId);
    const destinationList = getList(destination.droppableId);

    const [movedItem] = sourceList.splice(source.index, 1);
    destinationList.splice(destination.index, 0, movedItem);

    updateList(source.droppableId, sourceList);
    updateList(destination.droppableId, destinationList);

    if (
      (destination.droppableId === "A" && movedItem.board === "A") ||
      (destination.droppableId === "B" && movedItem.board === "B")
    ) {
      setScore((prevScore) => prevScore + 1);
    } else if (
      (source.droppableId === "A" && movedItem.board === "A") ||
      (source.droppableId === "B" && movedItem.board === "B")
    ) {
      setScore((prevScore) => Math.max(prevScore - 1, 0));
    }
  };

  return (
    <div /*className="layout_wrapper"*/ className={styles.Question}>
      <h2>Match the choices together</h2>
      <div className={styles.Matching__container}>
        <DragDropContext onDragEnd={handleDragEnd}>
          <div className="header"></div>

          <Droppable droppableId="allChoices" type="group">
            {(provided) => (
              <div
                {...provided.droppableProps}
                ref={provided.innerRef}
                className={styles.Mathing__choicesbox}
              >
                <h3>All Choices</h3>
                <div  className={styles.Question__choices__Matching}>
                  {allChoices.map((option, index) => (
                    <Draggable
                      key={option.value}
                      draggableId={option.value}
                      index={index}
                    >
                      {(provided) => (
                        <div
                          ref={provided.innerRef}
                          {...provided.draggableProps}
                          {...provided.dragHandleProps}
                          style={{
                            ...provided.draggableProps.style,
                          }}
                          aria-grabbed="true"
                          className={styles.Question__choice__Matching}
                        >
                          {option.value}
                          <span className={styles.icon}>≡</span>
                        </div>
                      )}
                    </Draggable>
                  ))}
                </div>
                {provided.placeholder}
              </div>
            )}
          </Droppable>
          <div className={styles.Mathing__answerboxs}>
            <Droppable droppableId="A" type="group">
              {(provided) => (
                <div
                  {...provided.droppableProps}
                  ref={provided.innerRef}
                  className={styles.Mathing__answerbox}
                >
                  <h3 className={styles.placeholder}>Group A</h3>
                  {choicesA.map((option, index) => (
                    <Draggable
                      key={option.value}
                      draggableId={option.value}
                      index={index}
                    >
                      {(provided) => (
                        <div
                          ref={provided.innerRef}
                          {...provided.draggableProps}
                          {...provided.dragHandleProps}
                          style={{
                            ...provided.draggableProps.style,
                          }}
                          aria-grabbed="true"
                          className={styles.Question__choice__Matching}
                        >
                          {option.value}
                          <span className={styles.icon}>≡</span>
                        </div>
                      )}
                    </Draggable>
                  ))}
                  {provided.placeholder}
                </div>
              )}
            </Droppable>

            <Droppable droppableId="B" type="group">
              {(provided) => (
                <div
                  {...provided.droppableProps}
                  ref={provided.innerRef}
                  className={styles.Mathing__answerbox}
                >
                  <h3 className={styles.placeholder}>Group B</h3>
                  {choicesB.map((option, index) => (
                    <Draggable
                      key={option.value}
                      draggableId={option.value}
                      index={index}
                    >
                      {(provided) => (
                        <div
                          ref={provided.innerRef}
                          {...provided.draggableProps}
                          {...provided.dragHandleProps}
                          style={{
                            ...provided.draggableProps.style,
                          }}
                          aria-grabbed="true"
                          className={styles.Question__choice__Matching}
                        >
                          {option.value}
                          <span className={styles.icon}>≡</span>
                        </div>
                      )}
                    </Draggable>
                  ))}
                  {provided.placeholder}
                </div>
              )}
            </Droppable>
          </div>
        </DragDropContext>

        <input type="hidden" name="score" value={score} />
      </div>
    </div>
  );
};

export default Matching;
