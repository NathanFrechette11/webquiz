import React, { startTransition } from "react";
import MultipleChoice from "@/app/_components/MultipleChoices";
import OneChoice from "@/app/_components/OneChoice";
import TrueFalse from "@/app/_components/TrueFalse";
import Number from "@/app/_components/Number";
import { updateOrCreateAttempt } from "../_actions/handleQuizSubmit";
import { validerReponses } from "../_actions/envoyerFormulaire";
import ShareQuiz from "./ShareQuiz";
import QuizRetro from "./QuizRetro";
import styles from "./PlayQuiz.module.css";

const PlayQuiz = ({
  quiz,
  userId,
  quizId,
  setAttempt,
  setIsFinished,
  retroQuiz,
  isOwner,
  sharedUsers,
}) => {
  const quizData = quiz.quizData;
  // // Parse options from JSON string
  const parseOptions = (options) => JSON.parse(options);

  const handleSubmit = async (formData) => {
    const allData = {
      formData: formData,
      quiz_id: quizId,
      totalBonneReponses: quizData.length,
    };
    const data = await validerReponses(allData);
    console.log("handled attempt", data);
    try {
      const newAttempt = {
        quiz_id: quizId,
        userId,
        score: data.score,
      };
      const settedAttempt = await updateOrCreateAttempt(data.attempt);
      console.log("settedattempt", settedAttempt);
      startTransition(() => {
        setAttempt(settedAttempt);
        setIsFinished(true);
      });
    } catch (error) {
      console.error("Erreur lors de la soumission :", error);
      // redirect("/site");
    }
  };

  const displayQuestion = (
    questionid,
    questiontitle,
    questionimg,
    type,
    optionsArray
  ) => {
    if (type === "true_false") {
      return (
        <TrueFalse
          className={styles.PlayQuiz__QuestionType}
          questionid={questionid}
          questiontitle={questiontitle}
          questionimg={questionimg}
          optionsArray={optionsArray}
          onAnswerChange={(answer) => handleAnswerChange(questionid, answer)}
        />
      );
    } else if (type === "number") {
      return (
        <Number
          className={styles.PlayQuiz__QuestionType}
          questionid={questionid}
          questiontitle={questiontitle}
          questionimg={questionimg}
          optionsArray={optionsArray}
          onAnswerChange={(answer) => handleAnswerChange(questionid, answer)}
        />
      );
    } else if (type === "one_choice") {
      return (
        <OneChoice
          className={styles.PlayQuiz__QuestionType}
          questionid={questionid}
          questiontitle={questiontitle}
          questionimg={questionimg}
          optionsArray={optionsArray}
          onAnswerChange={(answer) => handleAnswerChange(questionid, answer)}
        />
      );
    } else if (type === "multiple_choice") {
      return (
        <MultipleChoice
          className={styles.PlayQuiz__QuestionType}
          questionid={questionid}
          questiontitle={questiontitle}
          questionimg={questionimg}
          optionsArray={optionsArray}
          onAnswerChange={(answers) => handleAnswerChange(questionid, answers)}
        />
      );
    } else if (type == "matching") {
      totalBonnesReponses = totalBonnesReponses + optionsArray.length * 2;
      return (
        <Matching
          className={styles.PlayQuiz__QuestionType}
          questionid={questionid}
          questiontitle={questiontitle}
          questionimg={questionimg}
          optionsArray={optionsArray}
        />
      );
    } else if (type == "ordering") {
      totalBonnesReponses = totalBonnesReponses + optionsArray.length;
      return (
        <Ordering
          className={styles.PlayQuiz__QuestionType}
          questionid={questionid}
          questiontitle={questiontitle}
          questionimg={questionimg}
          optionsArray={optionsArray}
        />
      );
    }
  };
  return (
    <div className={styles.PlayQuiz}>
      <div className={styles.PlayQuiz__infos}>
        <div>
          <QuizRetro
            retroQuiz={retroQuiz}
            isOwner={isOwner}
            sharedUsers={sharedUsers}
            quizId={quizId}
          />
          <ShareQuiz quizId={quizId} />
          <h1 className={styles.PlayQuiz__title}>{quizData.quiztitle}</h1>
          <p>{quizData.name}</p>
        </div>
        <p className={styles.PlayQuiz__descript}>{quizData.quizdesc}</p>
      </div>

      {console.log("isOwner", isOwner)}
      {isOwner && (
        <div>
          <QuizRetro
            retroQuiz={retroQuiz}
            isOwner={isOwner}
            sharedUsers={sharedUsers}
            quizId={quizId}
          />
          <ShareQuiz quizId={quizId} />
        </div>
      )}
      <form action={handleSubmit} className={styles.PlayQuiz__questions}>
        {quizData.map(
          ({ questionid, questiontitle, questionimg, type, options }) => {
            const optionsArray = parseOptions(options);
            return (
              <div key={questionid} className={styles.PlayQuiz__question}>
                {displayQuestion(
                  questionid,
                  questiontitle,
                  questionimg,
                  type,
                  optionsArray
                )}
              </div>
            );
          }
        )}
        <button className={styles.submitButton} type="submit">
          Submit Answers
        </button>
      </form>
    </div>
  );
};

export default PlayQuiz;
