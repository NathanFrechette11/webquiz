"use client";
import React, { useEffect, useState } from "react";
import QuizUiCard from "../_components/QuizUiCard";
import styles from "./QuizList.module.css";

const QuizList = () => {
  const [quizzes, setQuizzes] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchQuizzes = async () => {
      try {
        // Accéder au fichier JSON dans le dossier public
        const resp = await fetch("/db/placeholderdb.json");
        const data = await resp.json();
        setQuizzes(data); // Remplir l'état avec les données récupérées
        setLoading(false); // Mettre à jour l'état de loading une fois les données récupérées
      } catch (error) {
        console.error("Erreur lors de la récupération des quiz :", error);
      }
    };

    fetchQuizzes();
  }, []); // L'effet se déclenche uniquement au premier rendu du composant

  return (
    <div className={styles.quizList}>
      {loading ? (
        <p>Chargement...</p> // Affiche un message de chargement
      ) : (
        quizzes.map((quiz) => (
          <QuizUiCard
            key={quiz.id} // Chaque quiz doit avoir une clé unique
            quiz={quiz} // Passe l'objet du quiz au composant QuizUiCard
          />
        ))
      )}
    </div>
  );
};

export default QuizList;
