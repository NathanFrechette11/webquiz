import React from "react";
import { oauthSigninAction } from "@/app/_actions/auth";
import styles from "./AuthForm.module.css";

const AuthForm = async ({ isLogin }) => {
  const submitAction = async (formData) => {
    "use server";
    if (isLogin) {
      console.log(formData);
    } else {
      console.log(formData);
    }
  };

  return (
    <div className={styles.Authwrapper}>
      <div className={styles.Auth}>
        <div className={styles.AuthFrom}>
          <h1 className={styles.loginSignUp}>
            {isLogin ? "Login" : "Sign Up"}
          </h1>
          <form action={submitAction}>
            <div>
              <label htmlFor="name" className={styles.label}>
                Name
              </label>
              <input
                type="text"
                id="name"
                name="name"
                required
                className={styles.input}
              />
            </div>
            <div>
              <label htmlFor="email" className={styles.label}>
                Email
              </label>
              <input
                type="email"
                id="email"
                name="email"
                required
                className={styles.input}
              />
            </div>
            <div>
              <label htmlFor="password" className={styles.label}>
                Password
              </label>
              <input
                type="password"
                id="password"
                name="password"
                required
                className={styles.input}
              />
            </div>
            <button type="submit" className={styles.auth__button}>
              Sign Up
            </button>
          </form>
        </div>
        <form action={oauthSigninAction}>
          <button type="submit" className={styles.auth__button}>
            Sign up with GitHub
          </button>
        </form>
      </div>
    </div>
  );
};

export default AuthForm;
