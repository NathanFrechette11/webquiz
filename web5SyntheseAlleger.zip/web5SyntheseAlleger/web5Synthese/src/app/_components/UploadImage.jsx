"use client";
import { UploadDropzone } from "../utils/uploadthing";
import { v4 as uuidv4 } from "uuid"; // Make sure you have the uuid library installed
import { imageResizeAndSquareCrop } from "../_helpers/squareifyimg";
import React from "react";

const UploadImage = ({ setQuizDataImage }) => {
  const handleUploadComplete = async (res) => {
    // Assuming 'res' contains the files that were selected for upload
    const renamedFiles = await Promise.all(
      res.map(async (file) => {
        // Generate a unique slug for the file
        const uniqueSlug = `${file.name
          .split(".")
          .slice(0, -1)
          .join(".")}-${uuidv4()}.${file.name.split(".").pop()}`;

        // Create a new File object with the new name
        const renamedFile = new File([file], uniqueSlug, { type: file.type });
        const uploadedFileUrl = res[0].url;
        setQuizDataImage(uploadedFileUrl);
        // Return the renamed file to be uploaded
        return renamedFile;
      })
    );

    // Proceed to upload renamed files
    await uploadFiles(renamedFiles);
  };

  const uploadFiles = async (files) => {
    const formData = new FormData();
    files.forEach((file) => {
      formData.append("file", file);
    });

    try {
      const response = await fetch("/api/uploadthing/files", {
        method: "POST",
        body: formData,
      });

      console.log("response", response.status);

      if (!response.ok) {
        throw new Error("Upload failed");
      }

      const data = await response.json(); // Assuming the server returns the file info in JSON
      console.log("Upload successful:", data);
    } catch (error) {
      console.error("Error uploading files:", error);
    }
  };
  return (
    <div className="mt-8 w-full max-w-md">
      <UploadDropzone
        endpoint="imageUploader"
        onClientUploadComplete={handleUploadComplete}
        onUploadError={(error) => {
          alert(`ERROR! ${error.message}`);
        }}
        onBeforeUploadBegin={async (files) => {
          // Map through files to create new File objects with renamed files
          const theFile = await imageResizeAndSquareCrop(
            files[0],
            1000,
            `${uuidv4()}-${files[0].name}`
          );
          // Return the renamed files for uploading
          console.log("uploaded iumage", theFile);
          return [theFile];
        }}
      />
    </div>
  );
};

export default UploadImage;
