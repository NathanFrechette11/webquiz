"use client"
import React from "react";
import styles from "./QuizRetro.module.css";
import { removeSharedUser } from "../_actions/shareQuiz";

const QuizRetro = ({ isOwner, sharedUsers, retroQuiz, quizId }) => {
  const handleRemove = async ({ quizId, userId }) => {
    console.log("removing user", userId);
    await removeSharedUser(quizId, userId);
  };
  let userData;
  return (
    <div>
      <div className={styles.QuizRetro__infos}>
        <p>Average score: {retroQuiz.point_avg}</p>
        <p>Number of attempts: {retroQuiz.attempts}</p>
      </div>

      {isOwner && sharedUsers != null && (
        <div>
          <div className={styles.QuizRetro__Title_container}>
            <p className={styles.QuizRetro__Title}>Shared users:</p>
          </div>
          {sharedUsers.map((user, i) => {
            return (
              <div className={styles.QuizRetro__Grid} key={i}>
                <div className={styles.QuizRetro__user}>
                  <p className={styles.QuizRetro__username}>
                    {user.username}
                  </p>
                  {user.avatar && (
                    <img
                      className={styles.profile_picture}
                      src={user.avatar}
                      alt="avatar"
                    />
                  )}
                  <button
                    className={styles.deleteButton}
                    onClick={() => handleRemove({ quizId, userId: user.id })}
                  >
                    Remove
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default QuizRetro;
