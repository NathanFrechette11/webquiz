"use client";
import React, { useState } from "react";
import styles from "./AvatarSelect.module.css";
import { modifyAvatar } from "../_actions/modifyProfile";
import UploadImage from "./UploadImage";

const AvatarSelect = ({ userId, canUpload, hasPics }) => {
  const [selectedOption, setSelectedOption] = useState(null);
  const [customAvatar, setCustomAvatar] = useState(null);
  const avatars = {
    1: {
      img: "https://utfs.io/f/GfpVxYFJq1nM4F5NSAC1vuIOMRNXoGVgB1DzQTKYSHbCPj7q",
      isUnlocked: true,
    },
    2: {
      img: "https://utfs.io/f/GfpVxYFJq1nMLaIqVvV2aDSnf4o70qPEQhRwTW3x5Ul6Mu1Y",
      isUnlocked: true,
    },
    3: {
      img: "https://utfs.io/f/GfpVxYFJq1nMpEQcRpYmaUuefSib3oXZQxhtNzBP0A1Yq7vg",
      isUnlocked: true,
    },
    4: {
      img: "https://utfs.io/f/GfpVxYFJq1nMpkvyU4OYmaUuefSib3oXZQxhtNzBP0A1Yq7v",
      isUnlocked: hasPics,
    },
    5: {
      img: "https://utfs.io/f/GfpVxYFJq1nMZFy3oReNV8ITdAjHR0ytmX5YPaezrvEUMBL3",
      isUnlocked: hasPics,
    },
    6: {
      img: "https://utfs.io/f/GfpVxYFJq1nM3lfRFGTOfcSVzEulxGgFh9pD1d2r80LRaWtQ",
      isUnlocked: hasPics,
    },
    7: {
      img: "https://utfs.io/f/GfpVxYFJq1nMRVWDcuQv3xE7hCjN51uJ2daBKclDbyfITGUH",
      isUnlocked: hasPics,
    },
    8: {
      img: "https://utfs.io/f/GfpVxYFJq1nMLoCP6R2aDSnf4o70qPEQhRwTW3x5Ul6Mu1Yg",
      isUnlocked: hasPics,
    },
    9: {
      img: "https://utfs.io/f/GfpVxYFJq1nMMwR180YE2WmElyb8DrjcA4ItPuafwkqUYK7V",
      isUnlocked: hasPics,
    },
    10: {
      img: "https://utfs.io/f/GfpVxYFJq1nMyewxcVktckd2VJzPGg9jlCb3KEYe5qaHvIi1",
      isUnlocked: hasPics,
    },
  };

  // Now, modify the options array
  const options = Array.from({ length: 10 }, (_, i) => ({
    id: i + 1,
    label: `Option ${i + 1}`,
    img: avatars[i + 1].img, // Access img from avatars
    isUnlocked: avatars[i + 1].isUnlocked, // Access isUnlocked from avatars
  }));

  console.log(options);
  const handleSubmit = (formData) => {
    if (selectedOption === options.length + 1) {
      modifyAvatar(customAvatar, userId);
      return;
    }
    modifyAvatar(avatars[formData.get("avatar")].img, userId);
  };

  const handleSelect = (optionId) => {
    setSelectedOption(optionId);
  };

  return (
    <div className={styles.FormRow}>
      <label>Choose an avatar</label>
      <form action={handleSubmit}>
        <div className={styles.RadioGroup}>
          {options.map((option) => (
            <label
              key={option.id}
              className={`${styles.RadioOption} ${
                selectedOption === option.id ? styles.Selected : ""
              }`}
            >
              <input
                type="radio"
                name="avatar"
                value={option.id}
                onChange={() => handleSelect(option.id)}
                checked={selectedOption === option.id}
                required
                disabled={!hasPics}
              />
              <img
                src={option.img}
                alt={option.label}
                className={styles.RadioImage}
              />
            </label>
          ))}
          {/* custom avatar */}
          <div>
            <label
              key={options.length + 1}
              className={`${styles.RadioOption} ${
                selectedOption === options.length + 1 ? styles.Selected : ""
              }`}
            >
              <input
                type="radio"
                name="avatar"
                value={options.length + 1}
                onChange={() => handleSelect(options.length + 1)}
                checked={selectedOption === options.length + 1}
                required
                disabled={!canUpload}
              />
              <img
                src="https://placehold.co/400"
                alt="Custom Image"
                className={styles.RadioImage}
              />
            </label>
            {selectedOption === options.length + 1 && (
              <div className={styles.formGroup}>
                <UploadImage setQuizDataImage={setCustomAvatar} />
              </div>
            )}
          </div>
        </div>
        <input type="submit" value="Confirm" className={styles.submitButton} />
      </form>
    </div>
  );
};

export default AvatarSelect;
