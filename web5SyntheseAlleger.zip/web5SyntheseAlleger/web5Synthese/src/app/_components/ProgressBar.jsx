import React from "react";
import styles from "./ProgressBar.module.css"; // Importation du fichier CSS

const ProgressBar = ({ xp, level }) => {
  const pourcent = Math.round(xp/level);
  console.log(pourcent);
  // styles.progress__bar
  return (
    <div className={styles.level__progressWrapper}>
      <div 
      className={styles.progress__bar}
      style={pourcent>0 ? { width: `${pourcent}%` } : {display: "none"}}
      >{pourcent}%</div>
    </div>
  );
};

export default ProgressBar;
