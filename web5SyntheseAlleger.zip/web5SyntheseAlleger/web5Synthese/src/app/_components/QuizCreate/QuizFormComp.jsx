import React, { useState } from "react";
import TrueFalse from "./QuizQuestions/TrueFalse";
import MultipleChoice from "./QuizQuestions/MultipleChoice";
import OrderingQuestion from "./QuizQuestions/OrderingQuestion";
import Number from "./QuizQuestions/Number";
import UploadImage from "../UploadImage";
import Matching from "./QuizQuestions/Matching";

const QuizFormComp = ({
  styles,
  handleSubmit,
  quizData,
  categories,
  questions,
  addQuestion,
  handleQuizChange,
  setCorrectAnswer,
  updateQuestion,
  updateAnswer,
  addAnswer,
  removeAnswer,
  removeQuestion,
  setQuizDataImage,
}) => {
  return (
    <form className={styles.formContainer} action={handleSubmit}>
      <h2 className={styles.formTitle}>Create Quiz</h2>
      <div className={styles.CreateQuiz__creation}>
        <div>
          <div
            // className={styles.formGroup}
            className={`${styles.formGroup} ${styles.quiz__color}`}
          >
            <label>Title</label>
            <input
              type="text"
              name="title"
              value={quizData.title}
              onChange={(e) => handleQuizChange(e.currentTarget)}
              required
              placeholder="Title"
            />
          </div>

          <div className={styles.formGroup}>
            <label>Category</label>
            <select
              name="category"
              value={quizData.category}
              onChange={(e) => handleQuizChange(e.currentTarget)}
              required
            >
              <option value="">Select a category</option>
              {categories.map((category) => (
                <option key={category.id} value={category.id}>
                  {category.name}
                </option>
              ))}
            </select>
          </div>
          <div className={styles.formGroup}>
            <UploadImage setQuizDataImage={setQuizDataImage} />
          </div>
        </div>
        <div>
          <label className={styles.Choice__radio__label}>Private quiz</label>
          <input
            className={styles.Choice__check__input}
            type="checkbox"
            onChange={(e) => handleQuizChange(e.currentTarget)}
            name="private"
          />
        </div>
        <div className={styles.formGroup}>
          <label>Description</label>
          <textarea
            className={styles.description__textarea}
            name="description"
            value={quizData.description}
            onChange={(e) => handleQuizChange(e.currentTarget)}
            placeholder="Description"
          />
        </div>
      </div>

      <div>
        <p className={styles.formTitle}>Questions</p>
        {questions.map((question, qIndex) => (
          <div className={styles.questionContainer} key={qIndex}>
            <div className={styles.questionAndType}>
              <div className={styles.questionHeader}>
                <label className={styles.question__text__label}>
                  Question Text
                </label>
                <input
                  type="text"
                  value={question.questionText}
                  className={styles.question__text__input}
                  onChange={(e) =>
                    updateQuestion(qIndex, "questionText", e.target.value)
                  }
                  required
                />
              </div>
              <div className={styles.type}>
                <label className={styles.create__type__label}>Type</label>
                <select
                  className={styles.select}
                  value={question.questionType}
                  onChange={(e) =>
                    updateQuestion(qIndex, "questionType", e.target.value)
                  }
                >
                  <option value="true_false">True or False</option>
                  <option value="one_choice">One Correct Choice</option>
                  <option value="multiple_choice">Multiple Choice</option>
                  <option value="number">Number Question</option>
                  <option value="ordering">Ordering</option>
                  <option value="matching">Matching</option>
                </select>
              </div>
            </div>

            {question.questionType === "true_false" && (
              <TrueFalse
                question={question}
                styles={styles}
                qIndex={qIndex}
                setCorrectAnswer={setCorrectAnswer}
              />
            )}

            {["one_choice", "multiple_choice"].includes(
              question.questionType
            ) && (
              <MultipleChoice
                question={question}
                styles={styles}
                qIndex={qIndex}
                setCorrectAnswer={setCorrectAnswer}
              />
            )}

            {["one_choice", "multiple_choice"].includes(
              question.questionType
            ) && (
                <MultipleChoice
                  question={question}
                  styles={styles}
                  qIndex={qIndex}
                  removeAnswer={removeAnswer}
                  updateAnswer={updateAnswer}
                  setCorrectAnswer={setCorrectAnswer}
                  addAnswer={addAnswer}
                />
              )}

            {question.questionType === "number" && (
              <Number
                question={question}
                styles={styles}
                qIndex={qIndex}
                updateQuestion={updateQuestion}
              />
            )}

            {question.questionType === "matching" && (
              <Matching
                question={question}
                styles={styles}
                qIndex={qIndex}
                updateQuestion={updateQuestion}
                removeAnswer={removeAnswer} // Replaces removeOrderItem
                updateAnswer={updateAnswer} // Replaces updateOrderItem
                addAnswer={addAnswer} // Replaces addOrderItem
              />
            )}

            {question.questionType === "ordering" && (
              <OrderingQuestion
                question={question}
                styles={styles}
                qIndex={qIndex}
                removeAnswer={removeAnswer} // Replaces removeOrderItem
                updateAnswer={updateAnswer} // Replaces updateOrderItem
                addAnswer={addAnswer} // Replaces addOrderItem
              />
            )}

            <button
              className={styles.deleteButton}
              type="button"
              onClick={() => removeQuestion(qIndex)}
            >
              Delete Question
            </button>
          </div>
        ))}
        <button
          className={styles.addButton}
          type="button"
          onClick={addQuestion}
        >
          Add Question ━━━━━━━━━━━━ +
        </button>
      </div>

      <button className={styles.submitButton} type="submit">
        Save Quiz
      </button>
    </form>
  );
};

export default QuizFormComp;
