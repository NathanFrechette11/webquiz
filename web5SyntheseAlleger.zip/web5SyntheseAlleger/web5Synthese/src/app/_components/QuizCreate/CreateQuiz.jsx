"use client";
import React, { useState, useEffect } from "react";
import styles from "./CreateQuiz.module.css";
import { createClient } from "../../_lib/supabase/client";
import QuizFormComp from "./QuizFormComp";
import { revalidatePath } from "next/cache";
import { CreateQuiz } from "@/app/_actions/createQuiz";

export const QuizForm = ({ categoriesArray, userId }) => {
  const supabase = createClient();
  const [categories, setCategories] = useState([]);
  const [questions, setQuestions] = useState([]);
  const [quizData, setQuizData] = useState({
    title: "",
    description: "",
    category: "",
    image: null,
    private: false,
  });

  useEffect(() => {
    const fetchCategories = async () => {
      setCategories(categoriesArray);
    };
    fetchCategories();
  }, [categoriesArray]);

  const handleQuizChange = ({ name, value }) => {
    setQuizData((prevData) => ({ ...prevData, [name]: value }));
  };

  const setQuizDataImage = (url) => {
    setQuizData((prevData) => ({ ...prevData, image: url }));
  };

  const addQuestion = () => {
    setQuestions([
      ...questions,
      {
        questionText: "",
        questionType: "true_false",
        answers: [
          { text: "true", isCorrect: false },
          { text: "false", isCorrect: false },
        ],
        numberAnswer: null, 
      },
    ]);
  };

  const removeQuestion = (qIndex) => {
    const updatedQuestions = questions.filter((_, index) => index !== qIndex);
    setQuestions(updatedQuestions);
  };

  const updateQuestion = (index, key, value) => {
    const updatedQuestions = [...questions];
    updatedQuestions[index][key] = value;
    setQuestions(updatedQuestions);
  };

  const updateAnswer = (qIndex, aIndex, key, value) => {
    const updatedQuestions = [...questions];
    updatedQuestions[qIndex].answers[aIndex][key] = value;
    setQuestions(updatedQuestions);
  };

  const setCorrectAnswer = (qIndex, aIndex) => {
    const updatedQuestions = [...questions];
    updatedQuestions[qIndex].answers = updatedQuestions[qIndex].answers.map(
      (answer, index) => ({
        ...answer,
        isCorrect: index === aIndex,
      })
    );
    setQuestions(updatedQuestions);
  };

  const addAnswer = (qIndex) => {
    const updatedQuestions = [...questions];
    const currentAnswers = updatedQuestions[qIndex].answers;

    if (currentAnswers.length >= 4) {
      alert("You can only have a maximum of 4 answers.");
    } else {
      updatedQuestions[qIndex].answers.push({ text: "", isCorrect: false });
      setQuestions(updatedQuestions);
    }
  };

  const removeAnswer = (qIndex, aIndex) => {
    const updatedQuestions = [...questions];
    updatedQuestions[qIndex].answers.splice(aIndex, 1);
    setQuestions(updatedQuestions);
  };

  const handleSubmit = async () => {
    console.log("quizData", quizData);
    const isPrivate = quizData.private === "on"? true:false;
    const category = parseInt(quizData.category);
    const obj = {
      title: quizData.title,
      description: quizData.description,
      category: category,
      image: quizData.image,
      isPrivate: isPrivate,
    };
    await CreateQuiz(obj, questions, userId);
  };

  return (
    <QuizFormComp
      styles={styles}
      handleSubmit={handleSubmit}
      quizData={quizData}
      categories={categories}
      questions={questions}
      addQuestion={addQuestion}
      handleQuizChange={handleQuizChange}
      setCorrectAnswer={setCorrectAnswer}
      updateQuestion={updateQuestion}
      removeAnswer={removeAnswer}
      removeQuestion={removeQuestion}
      updateAnswer={updateAnswer}
      addAnswer={addAnswer}
      setQuizDataImage={setQuizDataImage}
    />
  );
};

export default QuizForm;
