import React from "react";

const OrderingQuestion = ({
  question,
  styles,
  qIndex,
  removeAnswer,
  updateAnswer,
  addAnswer,
}) => {
  return (
    <div className={styles.answerList}>
      <h4 className={styles.instruction}>Answers in order</h4>
      <div className={styles.ordering}>
        <div>
          {question.answers.map((answer, aIndex) => (
            <div className={styles.answerItem} key={aIndex}>
              <input
                className={styles.question__text__input}
                type="text"
                value={answer.text}
                onChange={(e) =>
                  updateAnswer(qIndex, aIndex, "text", e.target.value)
                }
                required
              />
              <button
                type="button"
                onClick={() => removeAnswer(qIndex, aIndex)}
                className={styles.deleteButton}
              >
                X
              </button>
            </div>
          ))}
        </div>
        <span className={styles.icon}>↓</span>
      </div>
      <button
        className={styles.addButton}
        type="button"
        onClick={() => addAnswer(qIndex)}
        disabled={question.answers.length >= 4}
      >
        Add Answer
      </button>
    </div>
  );
};

export default OrderingQuestion;
