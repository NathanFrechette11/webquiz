import React from "react";

const Number = ({ styles, qIndex, updateQuestion }) => {
  return (
    <div className={styles.formGroup}>
      <label className={styles.instruction}>Answer</label>
      <span className={styles.Number__span}>
        <input
          type="number"
          placeholder="Enter the answer"
          onChange={(e) =>
            updateQuestion(qIndex, "numberAnswer", e.target.value)
          }
          required
        />
      </span>
    </div>
  );
};

export default Number;
