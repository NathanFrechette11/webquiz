import React from "react";

const MultipleChoice = ({
  question,
  styles,
  qIndex,
  removeAnswer,
  updateAnswer,
  setCorrectAnswer,
  addAnswer,
}) => {
  return (
    <div className={styles.answerList}>
      <h4 className={styles.instruction}>Answers</h4>
      <div className={styles.choices__answers}>
        {question.answers.map((answer, aIndex) => (
          <div className={styles.answerItem} key={aIndex}>
            <input
              className={styles.choices__input}
              type="text"
              value={answer.text}
              onChange={(e) =>
                updateAnswer(qIndex, aIndex, "text", e.target.value)
              }
              required
            />
            {question.questionType === "one_choice" && (
              <label className={styles.Choice__radio__label}>
                <input
                  className={styles.Choice__radio__input}
                  type="radio"
                  name={`correct-${qIndex}`}
                  checked={answer.isCorrect}
                  onChange={() => setCorrectAnswer(qIndex, aIndex)}
                />
              </label>
            )}
            {question.questionType === "multiple_choice" && (
              <label className={styles.Choice__radio__label}>
                <input
                  className={styles.Choice__check__input}
                  type="checkbox"
                  checked={answer.isCorrect}
                  onChange={(e) =>
                    updateAnswer(qIndex, aIndex, "isCorrect", e.target.checked)
                  }
                />
              </label>
            )}
            <button
              type="button"
              onClick={() => removeAnswer(qIndex, aIndex)}
              className={styles.deletebutton}
            >
              X
            </button>
          </div>
        ))}
      </div>
      <button
        className={styles.addButton}
        type="button"
        onClick={() => addAnswer(qIndex)}
        disabled={question.answers.length >= 4}
      >
        Add Answer
      </button>
    </div>
  );
};

export default MultipleChoice;
