import React from "react";

const TrueFalse = ({ question, styles, qIndex, setCorrectAnswer }) => {
  // Assume that the question object contains two possible answers (True and False)
  // Each answer has a text and an `isCorrect` flag

  return (
    <div className={styles.answerList}>
      <h4 className={styles.instruction}>Answers</h4>
      <div className={styles.TrueFalse__answers}>
        <div className={styles.answerItem}>
          <label className={styles.Choice__radio__label}>
            True
            <input
              className={styles.Choice__radio__input}
              type="radio"
              name={`correct-${qIndex}`}
              checked={question.answers[0].isCorrect}
              onChange={() => setCorrectAnswer(qIndex, 0)} // For True
            />
          </label>
        </div>
        <div className={styles.answerItem}>
          <label className={styles.Choice__radio__label}>
            False
            <input
              className={styles.Choice__radio__input}
              type="radio"
              name={`correct-${qIndex}`}
              checked={question.answers[1].isCorrect}
              onChange={() => setCorrectAnswer(qIndex, 1)} // For False
            />
          </label>
        </div>
      </div>
    </div>
  );
};

export default TrueFalse;
