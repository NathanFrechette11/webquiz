import React from "react";
const Matching = ({
  question,
  qIndex,
  styles,
  removeAnswer,
  updateAnswer,
  addAnswer,
}) => {
  return (
    <div className={styles.answerList}>
      <h4 className={styles.instruction}>Matching Answers</h4>
      <div className={styles.matchingGrid}>
        {question.answers.map((answer, aIndex) => (
          <div
            className={`${styles.answerItem} ${styles.answerItem__row}`}
            key={aIndex}
          >
            {/* Column A Input */}
            <input
              className={styles.choices__input}
              type="text"
              value={answer.columnA || ""}
              placeholder="Column A"
              onChange={(e) =>
                updateAnswer(qIndex, aIndex, "columnA", e.target.value)
              }
              required
            />
            <span className={styles.icon}>↔</span>
            {/* Column B Input */}
            <input
              className={styles.choices__input}
              type="text"
              value={answer.columnB || ""}
              placeholder="Column B"
              onChange={(e) =>
                updateAnswer(qIndex, aIndex, "columnB", e.target.value)
              }
              required
            />

            {/* Remove Button */}
            <button
              className={styles.deleteButton}
              type="button"
              onClick={() => removeAnswer(qIndex, aIndex)}
            >
              X
            </button>
          </div>
        ))}
      </div>
      <button
        className={styles.addButton}
        type="button"
        onClick={
          () => addAnswer(qIndex, { columnA: "", columnB: "" }) // Add blank matching pair
        }
        disabled={question.answers.length >= 6} // Limit the number of pairs
      >
        Add Pair
      </button>
    </div>
  );
};

export default Matching;
