"use client"

import React, { useRef } from "react";
import styles from "./ShareQuiz.module.css";
import { ShareQuizAction } from "../_actions/shareQuiz";

const ShareQuiz = ({ quizId, setQuizData }) => {
  const formRef = useRef(null);

  const handleSubmit = (event) => {
    event.preventDefault(); // Prevent page reload

    if (!formRef.current || !(formRef.current instanceof HTMLFormElement)) {
      console.error("Invalid form reference.");
      return;
    }

    const formData = new FormData(formRef.current);
    const shareOption = formData.get("shareOption");
    const inputValue = formData.get("inputValue");

    switch (shareOption) {
      case "username":
        ShareQuizAction({ username: inputValue, quizId, isEmail: false });
        break;
      case "email":
        ShareQuizAction({ email: inputValue, quizId, isEmail: true });
        break;
      default:
        console.error("Invalid share option");
    }
  };

  return (
    <div>
      <form ref={formRef} onSubmit={handleSubmit} className={styles.sharequiz__form}>
        <div className={styles.sharequiz__choices}>
          <h1 className={styles.ShareQuiz__title}>Share this quiz</h1>
          <label className={styles.sharequiz__choice}>
            <input type="radio" name="shareOption" value="username" required /> Username
          </label>
          <label className={styles.sharequiz__choice}>
            <input type="radio" name="shareOption" value="email" required /> Email
          </label>
        </div>
        <input
          type="text"
          name="inputValue"
          placeholder="Enter user"
          required
          className={styles.sharequiz__input}
        />
        <button type="submit" className={styles.sharequiz__submit}>
          Send
        </button>
      </form>
    </div>
  );
};

export default ShareQuiz;
