import Link from "next/link";
import React from "react";
import styles from "./Footer.module.css";

const Footer = () => {
  return (
    <header className={styles.Footer}>
      <li className={styles.item}>
        <Link href="/">Home</Link>
      </li>
      <li className={styles.item}>
        <Link href="/site">Quizzes</Link>
      </li>
      <li className={styles.item}>
        <Link href="/quiz/create">Create Quiz</Link>
      </li>
      <li className={styles.item}>
        <Link href="/UiProfil">Profil</Link>
      </li>
      <li className={styles.item}>
        <Link href="/auth/logout">Logout</Link>
      </li>
    </header>
  );
};

export default Footer;
