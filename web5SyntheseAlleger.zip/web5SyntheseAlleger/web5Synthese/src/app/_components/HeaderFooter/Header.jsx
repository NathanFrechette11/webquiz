"use client";
import Link from "next/link";
import React from "react";
import { usePathname } from "next/navigation";
import styles from "./Header.module.css";

const Header = () => {
  const pathname = usePathname(); // Obtenir l'URL actuelle

  return (
    <header className={styles.Header}>
  <li className={styles.item}>
    <Link href="/" className={`${styles.link} ${pathname === "/" ? styles.active : ""}`}>
      Home
    </Link>
  </li>
  <li className={styles.item}>
    <Link href="/site" className={`${styles.link} ${pathname === "/site" ? styles.active : ""}`}>
      Quizzes
    </Link>
  </li>
  <li className={styles.item}>
    <Link href="/quiz/create" className={`${styles.link} ${pathname === "/quiz/create" ? styles.active : ""}`}>
      Create Quiz
    </Link>
  </li>
  <li className={styles.item}>
    <Link href="/profile" className={`${styles.link} ${pathname === "/profile" ? styles.active : ""}`}>
      Profil
    </Link>
  </li>
  <li className={`${styles.item} ${pathname === "/auth/logout" ? styles.active : ""} ${styles.item__red}`}>
    <Link href="/auth/logout" className={`${styles.link} ${styles.link__red}`}>
      Logout
    </Link>
  </li>
</header>
  );
};

export default Header;
