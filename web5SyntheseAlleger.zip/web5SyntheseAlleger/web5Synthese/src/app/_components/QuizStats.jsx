import React from 'react'

const QuizStats = ({ avgPercent, attempsCount }) => {
    return (
        <div>
            <h1>Quiz stats</h1>
            <p>Average success rate: {avgPercent}</p>
            <p>Attempts: {attempsCount}</p>
        </div>
    )
}

export default QuizStats