'use client';

import { useState } from 'react';
import { BanQuiz } from '../_actions/banUpdateThings';

const FormBanQuiz = ({ quizId, title, initialIsBanned, initialDescBanned }) => {
  const [isBanned, setIsBanned] = useState(initialIsBanned);
  const [descBan, setDescBan] = useState(initialDescBanned || "");

  const handleIsBannedChange = (e) => {
    setIsBanned(e.target.value === 'true');
  };

  const handleDescBanChange = (e) => {
    setDescBan(e.target.value);
  };

  return (
    <form action={BanQuiz}>
      <label>
        <input type="hidden" name="quiz_id" value={quizId} />
        <p>{title} :</p>
        <input
          type="radio"
          name="isBanned"
          value="true"
          checked={isBanned === true}
          onChange={handleIsBannedChange}
        />
        <span>Banned</span>
        <input
          type="radio"
          name="isBanned"
          value="false"
          checked={isBanned === false}
          onChange={handleIsBannedChange}
        />
        <span>Unbanned</span>
      </label>
      <br />
      <textarea
        style={{ width: "400px", height: "100px" }}
        name="descBan"
        placeholder="Reason for the ban..."
        value={descBan}
        onChange={handleDescBanChange}
      />
      <br />
      <button type="submit">Update</button>
    </form>
  );
};

export default FormBanQuiz;
