import React from "react";
import styles from "./BadgeandReward.module.css"; // Importation du fichier CSS

const BadgeandReward = ({ text, icon, isUnlocked }) => {
  // Determine the correct style class based on isUnlocked
  const containerClass = isUnlocked
    ? styles.BadgeandReward
    : styles.BadgeandRewardLocked;
  const iconClass = isUnlocked
    ? styles.BadgeandReward__icon
    : styles.BadgeandRewardLocked__icon;
  const textClass = isUnlocked
    ? styles.BadgeandReward__text
    : styles.BadgeandRewardLocked__text;

  return (
    <div className={containerClass}>
      <span className={iconClass}>{icon}</span>
      <span className={textClass}>{text}</span>
    </div>
  );
};

export default BadgeandReward;
