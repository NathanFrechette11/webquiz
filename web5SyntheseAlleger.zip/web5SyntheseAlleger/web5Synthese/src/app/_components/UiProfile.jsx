"use client";
import React, { useState } from "react";
import BadgeandReward from "../_components/BadgeandReward";
import ProgressBar from "../_components/ProgressBar";
import AvatarSelect from "./AvatarSelect";
import styles from "./UiProfile.module.css";
import { modifyUsername } from "../_actions/modifyProfile";

const UiProfile = ({ profile, userId, userAchievements, allAchievements }) => {
  const [usernameForm, setUsernameForm] = useState(false);
  const [customAvatar, setCustomeAvatar] = useState(null);
  const profileData = profile.data;
  const handleUsernameSubmit = (formData) => {
    const username = formData.get("username");
    console.log("formdata", username);
    modifyUsername(username, userId);
  };
  console.log("profile", profile);
  const unlockedAchievements = userAchievements.data.map(
    (ua) => ua.achievements.name
  );

  const hasFirstConnectionAchievement =
    unlockedAchievements.includes("First connection");
  const hasTrackRecordAchievement =
    unlockedAchievements.includes("Track record");
  const hasFirstQuizAchievement = unlockedAchievements.includes("First quiz");
  const hasMirrorMirrorAchievement =
    unlockedAchievements.includes("Mirror mirror...");

  return (
    <div className={styles.Profil}>
      <div className={styles.Profil__user}>
        <div className={styles.Profil__infos}>
          <img src={profileData.avatar} alt="" className={styles.img} />
          <div>
            <h2 className={styles.infos__username}>{profileData.username}</h2>
            {hasTrackRecordAchievement && (
              <>
                <button onClick={() => setUsernameForm(!usernameForm)}>
                  ✐
                </button>
                {usernameForm && (
                  <form action={handleUsernameSubmit}>
                    <input
                      type="text"
                      name="username"
                      placeholder="Enter your new username"
                      className={styles.Profil__nameinput}
                    />
                    <button type="submit" className={styles.submitButton}>
                      Confirm username change
                    </button>
                  </form>
                )}
              </>
            )}
          </div>
          <p className={styles.infos__email}>{profileData.email}</p>
        </div>
        <div className={styles.profil__level}>
          <p className={styles.level__level}>Level {profileData.level}</p>
          <ProgressBar xp={profileData.xp} level={profileData.level} />
        </div>
      </div>
      {hasFirstQuizAchievement && (
        <AvatarSelect
          userId={userId}
          canUpload={hasMirrorMirrorAchievement}
          hasPics={hasFirstConnectionAchievement}
        />
      )}

      <div className={styles.badges}>
        <h2 className={styles.badges__title}>My Badges</h2>
        <div className={styles.badges__badges}>
          {allAchievements.data.map((achievement) => {
            const isUnlocked = unlockedAchievements.includes(achievement.name);
            return (
              <BadgeandReward
                key={achievement.name}
                text={achievement.name}
                icon={achievement.icon}
                isUnlocked={isUnlocked}
              />
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default UiProfile;
