"use client";
import React, { useState } from "react";
import PlayQuiz from "./PlayQuiz";
import { createClient } from "../_lib/supabase/client";
import QuizFeedback from "./QuizFeedback";

const QuizId = ({ quiz, userId, quizId, retroQuiz, isOwner, sharedUsers}) => {
  const supabase = createClient();
  const [attempt, setAttempt] = useState(null);
  const [isFinished, setIsFinished] = useState(false);
  return isFinished ? (
    <QuizFeedback attempt={attempt} />
  ) : (
    <PlayQuiz
      sharedUsers={sharedUsers}
      attempt={attempt}
      quiz={quiz}
      quizId={quizId}
      setAttempt={setAttempt}
      isFinished={isFinished}
      setIsFinished={setIsFinished}
      userId={userId}
      retroQuiz={retroQuiz}
      isOwner={isOwner}
      supabase={supabase}
    />
  );
};

export default QuizId;
