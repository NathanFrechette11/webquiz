"use client";

import { useState, useEffect } from "react";
import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd";
import styles from "./PlayQuiz.module.css";

const Ordering = ({ questionid, questiontitle, optionsArray }) => {
  const [items, setItems] = useState([]);
  const [score, setScore] = useState(0);

  const calculateScore = (itemsList) => {
    return itemsList.reduce((acc, item, index) => {
      return acc + (item.order === index ? 1 : 0);
    }, 0);
  };

  useEffect(() => {
    if (optionsArray && optionsArray.length > 0) {
      const shuffledItems = [...optionsArray].sort(() => Math.random() - 0.5);

      setItems(shuffledItems);

      setScore(calculateScore(shuffledItems));
    }
  }, [optionsArray]);

  const handleDragEnd = (result) => {
    const { source, destination } = result;

    if (!destination) return;

    const updatedItems = Array.from(items);
    const [movedItem] = updatedItems.splice(source.index, 1);
    updatedItems.splice(destination.index, 0, movedItem);

    setItems(updatedItems);
    setScore(calculateScore(updatedItems));
  };

  return (
    <div className="ordering-question">
      <h3 className={styles.Question__title}>{questiontitle}</h3>
      <DragDropContext onDragEnd={handleDragEnd}>
        <Droppable droppableId={`droppable-${questionid}`}>
          {(provided) => (
            <div
              {...provided.droppableProps}
              ref={provided.innerRef}
              className={styles.Question__order}
            >
              {items.map((item, index) => (
                <Draggable
                  key={item.order}
                  draggableId={item.order.toString()}
                  index={index}
                >
                  {(provided) => (
                    <div
                      ref={provided.innerRef}
                      {...provided.draggableProps}
                      {...provided.dragHandleProps}
                      style={{
                        ...provided.draggableProps.style,
                        marginBottom: "10px",
                        padding: "10px",
                        border: "1px solid black",
                        backgroundColor: "#f4f4f4",
                      }}
                      className={styles.Question__choice__order}
                    >
                      {item.text}
                      <span className={styles.icon}>≡</span>
                    </div>
                  )}
                </Draggable>
              ))}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </DragDropContext>

      <input type="hidden" name={`scoreOrdering`} value={score} />
    </div>
  );
};

export default Ordering;
