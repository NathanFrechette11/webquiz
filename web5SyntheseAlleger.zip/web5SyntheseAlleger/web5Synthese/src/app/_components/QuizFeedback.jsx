import styles from "../_components/QuizRetro.module.css";
import React from "react";

const QuizFeedback = ({ attempt }) => {
  console.log("attempt", attempt);
  return (
    <div>
      <div className={styles.QuizRetro__Title_container}>
        <h1 className={styles.QuizRetro__Title}>Results</h1>
      </div>
      <div className={styles.QuizRetro__infos}>
        <p>Your score: {attempt.percentage}%</p>
        <p>Average Score: {attempt.score}</p>
      </div>
    </div>
  );
};

export default QuizFeedback;
