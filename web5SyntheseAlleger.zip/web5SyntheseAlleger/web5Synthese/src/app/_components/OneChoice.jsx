import styles from "./PlayQuiz.module.css";

const OneChoice = ({
  questionid,
  questiontitle,
  questionimg,
  optionsArray,
}) => {
  console.log("Props reçues dans OneChoice :", {
    questionid,
    questiontitle,
    questionimg,
    optionsArray,
  });
  return (
    <div key={questionid} className={styles.Question}>
      {questionimg && <img src={questionimg} alt={questiontitle} />}
      <h3 className={styles.Question__title}>{questiontitle}</h3>
      <div className={styles.Question__choices}>
        {optionsArray.map((option, index) => {
          return (
            <div key={index}>
              <label className={styles.Question__choice}>
                <input
                  className={styles.Choice__radio__input}
                  type="radio"
                  name={`question_${questionid}`}
                  value={option.isCorrect}
                />
                <span className={styles.choice__answer}>{option.text}</span>
              </label>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default OneChoice;
