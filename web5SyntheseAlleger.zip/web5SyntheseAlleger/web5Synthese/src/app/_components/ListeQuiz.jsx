"use client";

import Link from "next/link";
import { useState } from "react";
import InfiniteScroll from "react-infinite-scroll-component";
import { chercherQuiz } from "../_actions/chercherElement";
import { QUIZ_PER_PAGE } from "../_constants/quiz";
import QuizUiCard from "./QuizUiCard";

const ListeQuiz = ({ quizzesInitial }) => {
  const [quizzes, setQuizzes] = useState(quizzesInitial);
  const [moreToLoad, setMoreToLoad] = useState(true);

  const loadMoreData = async () => {
    const nextStartIndex = quizzes.length; // Utilisez la longueur actuelle comme index de départ
    const newQuizzes = await chercherQuiz(nextStartIndex); // Chargez les nouveaux quiz à partir de cet index

    if (newQuizzes.length < QUIZ_PER_PAGE) {
      setMoreToLoad(false); // Si moins de quiz que prévu sont chargés, arrêtez de charger davantage
    }

    setQuizzes((prev) => [...prev, ...newQuizzes]); // Ajoutez les nouveaux quiz à la liste existante
  };

  if (!quizzes || quizzes.length === 0) {
    return <p>No quizzes match your search. Please try a different keyword. </p>;
  }

  return (
    <div>
      <InfiniteScroll
        dataLength={quizzes.length}
        next={loadMoreData}
        hasMore={moreToLoad}
        loader={<h4>Loading...</h4>}
        endMessage={
          <p style={{ textAlign: "center" }}>
            <b>Yay! You have seen it all</b>
          </p>
        }
      >
        {quizzes.map((quiz) => (
          <div key={quiz.id}>
          <QuizUiCard quiz={quiz} />
        </div>
        ))}
      </InfiniteScroll>
    </div>
  );
};

export default ListeQuiz;
