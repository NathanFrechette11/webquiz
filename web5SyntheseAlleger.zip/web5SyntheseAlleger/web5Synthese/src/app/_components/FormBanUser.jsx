'use client';

import { useState } from 'react';
import { BanUser } from '../_actions/banUpdateThings';

const FormBanUser = ({ userId, username, initialIsBanned, initialIsAdmin, initialDescBanned }) => {
  const [isBanned, setIsBanned] = useState(initialIsBanned);
  const [isAdmin, setIsAdmin] = useState(initialIsAdmin);
  const [descBan, setDescBan] = useState(initialDescBanned || "");

  const handleIsBannedChange = (e) => {
    setIsBanned(e.target.value === 'true');
  };
  
  const handleIsAdminChange = (e) => {
    setIsAdmin(e.target.value === 'true');
  };

  const handleDescBanChange = (e) => {
    setDescBan(e.target.value);
  };

  return (
    <form action={BanUser}>
      <label>
        <input type="hidden" name="user_id" value={userId} />
        <p>{username} :</p>
        <input
          type="radio"
          name="isBanned"
          value="true"
          checked={isBanned === true}
          onChange={handleIsBannedChange}
        />
        <span>Banned</span>
        <input
          type="radio"
          name="isBanned"
          value="false"
          checked={isBanned === false}
          onChange={handleIsBannedChange}
        />
        <span>Unbanned</span>

        <br />

        <input
          type="radio"
          name="isAdmin"
          value="true"
          checked={isAdmin === true}
          onChange={handleIsAdminChange}
        />
        <span>Admin</span>
        <input
          type="radio"
          name="isAdmin"
          value="false"
          checked={isAdmin === false}
          onChange={handleIsAdminChange}
        />
        <span>Not admin</span>

      </label>
      <br />
      <textarea
        style={{ width: "400px", height: "100px" }}
        name="descBan"
        placeholder="Reason for the ban..."
        value={descBan}
        onChange={handleDescBanChange}
      />
      <br />
      <button type="submit">Update</button>
    </form>
  );
};

export default FormBanUser;
