import React from "react";
import styles from "./QuizUiCard.module.css";
import Link from "next/link";
import { selectProfileAction } from "../_actions/getProfile";

const QuizUiCard = ({ quiz }) => {
  console.log(quiz);
  return (
    <div className={styles.quizCard}>
      <div>
        <Link href={`quiz/${quiz.id}`}>
          <img
            src={
              quiz.image ||
              "https://utfs.io/f/GfpVxYFJq1nMTVGOyQ6ntIfyZsGq87CVW5cOMlz9dum06SpJ"
            }
            alt={quiz.title}
            className={`${styles.quizCard__img} ${
              styles[`quizCard__img__${quiz.category.color}`]
            }`}
          />
          <div className={styles.quizCard__infos}>
            <p
              className={`${styles.quizCard__category} ${
                styles[`quizCard__cat__${quiz.category.color}`]
              }`}
            >
              {quiz.category.name}
            </p>
            <p className={styles.quizCard__title}>{quiz.title}</p>
            {quiz.is_banned && (
                <p>This quiz has been banned.</p>
              )}
          </div>
        </Link>
      </div>
    </div>
  );
};

export default QuizUiCard;
