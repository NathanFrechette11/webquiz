// pages/api/uploadthing/files.js

import { getFilesAction } from "@/app/_actions/getFiles";

export default async function handler(req, res) {
    if (req.method === 'GET') {
        return getFilesAction(req, res);
    }
    res.setHeader('Allow', ['GET']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
}
