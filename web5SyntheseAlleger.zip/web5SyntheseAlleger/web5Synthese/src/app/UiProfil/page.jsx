import React from "react";
import styles from "./page.module.css";
import BadgeandReward from "../_components/BadgeandReward";
import ProgressBar from "../_components/ProgressBar";

const UiProfil = () => {
  return (
    <div className={styles.Profil}>
      <div className={styles.Profil__user}>
        <div className={styles.Profil__infos}>
          <img src="https://picsum.photos/200" alt="" className={styles.img} />
          <h2 className={styles.infos__username}>Username</h2>
          <p className={styles.infos__email}>Email@123abc.com</p>
        </div>
        <div className={styles.profil__level}>
          <p className={styles.level__level}>Level 7</p>
          <ProgressBar pourcent={35} />
        </div>
      </div>

      <div className={styles.badges}>
        <h2 className={styles.badges__title}>My Badges</h2>
        <div className={styles.badges__badges}>
          <BadgeandReward text="Achievement Unlocked" icon="🏆" />
          <BadgeandReward text="First Login" icon="🔑" />
          <BadgeandReward text="Top Scorer" icon="⭐" />
          <BadgeandReward text="Quiz Master" icon="🎓" />
          <BadgeandReward text="Speed Runner" icon="⚡" />
          <BadgeandReward text="Daily Streak" icon="🔥" />
          <BadgeandReward text="Social Butterfly" icon="🦋" />
          <BadgeandReward text="Explorer" icon="🌍" />
          <BadgeandReward text="Team Player" icon="🤝" />
          <BadgeandReward text="Early Bird" icon="🐦" />
          <BadgeandReward text="Night Owl" icon="🦉" />
          <BadgeandReward text="Hard Worker" icon="💪" />
          <BadgeandReward text="Lucky Charm" icon="🍀" />
          <BadgeandReward text="Bookworm" icon="📚" />
          <BadgeandReward text="Puzzle Solver" icon="🧩" />
          <BadgeandReward text="Globetrotter" icon="✈️" />
        </div>
      </div>
      <div className={styles.rewards}>
        <h2 className={styles.rewards__title}>My Rewards</h2>
        <div className={styles.rewards__rewards}>
          <div className={styles.rewards__rewards}>
            <BadgeandReward text="Exclusive Item" icon="🎁" />
            <BadgeandReward text="Bonus Points" icon="💯" />
            <BadgeandReward text="Gift Card" icon="🎟️" />
            <BadgeandReward text="Discount Code" icon="💸" />
            <BadgeandReward text="Mystery Box" icon="📦" />
            <BadgeandReward text="Free Quiz Pack" icon="🆓" />
            <BadgeandReward text="VIP Access" icon="👑" />
            <BadgeandReward text="Extra Life" icon="❤️" />
            <BadgeandReward text="Hidden Feature" icon="🔒" />
            <BadgeandReward text="Collectible Badge" icon="🏅" />
            <BadgeandReward text="Level Up" icon="⬆️" />
            <BadgeandReward text="Premium Avatar" icon="🖼️" />
            <BadgeandReward text="Surprise Reward" icon="✨" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default UiProfil;
