import React from "react";
import UiProfile from "../_components/UiProfile";
import {
  getAllAchievements,
  getUserAchievements,
  selectProfileAction,
} from "../_actions/getProfile";
import { createClient } from "../_lib/supabase/server";
import { redirect } from "next/navigation";
import Link from "next/link";
import styles from "../_components/UiProfile.module.css";

const UiProfil = async () => {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  const profile = await selectProfileAction(user.id);

  if (profile.data.is_banned) {
    redirect(`/banned`);
  }

  const { data: profileQuiz } = await supabase
    .from("quizcompletedbyprofiles")
    .select()
    .eq("id_profile", profile.data.id);

  console.log("ADASFDSFSFFDGFD", profileQuiz);

  // const profile = await selectProfileAction(user.id);

  const achievements = await getUserAchievements(user.id);
  console.log("achievements", achievements);
  const allAchievements = await getAllAchievements();
  console.log("allachievements", allAchievements);

  return (
    <div>
      <UiProfile
        profile={profile}
        userId={user.id}
        userAchievements={achievements}
        allAchievements={allAchievements}
      />
      <div>
        <div className={styles.secTitle_container}>
          <h2 className={styles.secTitle}>Played Quizzes :</h2>
        </div>
        <div className={styles.playedquizzes}>
          {profileQuiz.map(({ id, id_quiz, score, quiz_title }) => (
            <div key={id}>
              <Link href={`quiz/${id_quiz}`} className={styles.Link}>
                <p className={styles.Link__Title}>{quiz_title}</p>
                <p className={styles.Link__Score}>Previous Score : {score}%</p>
              </Link>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default UiProfil;
