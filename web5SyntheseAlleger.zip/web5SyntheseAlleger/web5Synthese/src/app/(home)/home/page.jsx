import { selectProfileAction } from '@/app/_actions/getProfile';
import { createClient } from '@/app/_lib/supabase/server'
import React from 'react'

const HomePage = async () => {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const { data } = await selectProfileAction(user.id);
  console.log("homepage", data);
  return (
    <div>
      <h1>Welcome {data.username}!</h1>
      <p>This is the most site of all time</p>
    </div>
  )
}

export default HomePage