import React from "react";
import styles from "./page.module.css";
import PlayButton from "../_components/PlayButton";

const UiQuizPage = () => {
  return (
    <div className={styles.UiQuizPage}>
      <div className={styles.UiQuizPage__Left}>
        <img
          src="https://picsum.photos/200"
          alt=""
          className={styles.Left__img}
        />
        <div className={styles.Left__infos}>
          <p>26 questions</p>
          <span>┃</span>
          <p>44 points</p>
        </div>
        <PlayButton props={"Play"} />
      </div>
      <div className={styles.UiQuizPage__Right}>
        <h1 className={styles.Right__title}>Title</h1>
        <p className={styles.Right__created_by}>User</p>
        <p className={styles.Right__description}>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Vel
          exercitationem inventore a ad ea labore optio voluptate, non alias
          harum, asperiores veritatis hic ab, reprehenderit dolor tenetur
          blanditiis dignissimos rerum.
        </p>
      </div>
    </div>
  );
};

export default UiQuizPage;
