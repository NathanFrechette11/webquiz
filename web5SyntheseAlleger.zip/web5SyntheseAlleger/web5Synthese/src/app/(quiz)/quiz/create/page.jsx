import { fetchCategories } from "@/app/_actions/getCategories";
import QuizForm from "@/app/_components/QuizCreate/CreateQuiz";
import { createClient } from "@/app/_lib/supabase/server";
import React from "react";
import styles from "./page.module.css";
import { redirect } from "next/navigation";

const CreateQuizPage = async () => {
  const supabase = createClient();
  const categories = await fetchCategories();
  const { data: { user } } = await supabase.auth.getUser();
  
  const { data: profile } = await supabase
    .from('profiles')
    .select()
    .eq('id', user.id)
    .single();

  if(profile.is_banned)
  {
    redirect(`/banned`);
  }

  console.log("user", user)
  return (
    <div>
      <QuizForm categoriesArray={categories} userId={user.id} />
    </div>
  );
};

export default CreateQuizPage;
