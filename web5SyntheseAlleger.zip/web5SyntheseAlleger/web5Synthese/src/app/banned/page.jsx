"server-only";
import styles from "./page.module.css";
import { createClient } from "../_lib/supabase/server";

const BannedPage = async () => {
  const supabase = createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { data: profile } = await supabase
    .from("profiles")
    .select()
    .eq("id", user.id)
    .single();
  return (
    <div className={styles.banMessage}>
      <h1 className={styles.banMessage__title}>
        You were banned from our website
      </h1>
      <p className={styles.banMessage__text}>
        Unfortunately, you were banned from our website and can no longer use
        our website with this account.
      </p>
      <p className={styles.banMessage__reason}>
        You were banned for this reason: <span>{profile.desc_banned}</span>
      </p>
    </div>
  );
};
export default BannedPage;
