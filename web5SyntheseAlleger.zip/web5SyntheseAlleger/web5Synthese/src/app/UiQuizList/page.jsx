import React from "react";
import QuizList from "../_components/QuizList";
import styles from "./page.module.css";

const UiQuizList = () => {
  return (
    <div className={styles.UiQuizList}>
      <QuizList />
    </div>
  );
};

export default UiQuizList;
