import React from "react";
import styles from "./notfoundLoading.module.css";

const loading = () => {
  return (
    <div className={styles.loading__Container}>
      <h1 className={styles.loading__Title}>Loading...</h1>
      <p className={styles.loading__Description}>
        Please wait while we load your content.
      </p>
    </div>
  );
};

export default loading;
