import AuthForm from '@/app/_components/AuthForm'
import React from 'react'

const LoginPage = () => {
  return (
    <AuthForm/>
  )
}

export default LoginPage
