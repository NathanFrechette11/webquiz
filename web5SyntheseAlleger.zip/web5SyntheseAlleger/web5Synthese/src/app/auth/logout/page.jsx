import { createClient } from '@/app/_lib/supabase/server';
import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';
import React from 'react'

const LogoutPage = async() => {
    const supabase = await createClient();
    const { error } = await supabase.auth.signOut();
    revalidatePath("/auth/login");
    redirect("/auth/login");
  return (
    <div>Logging out...</div>
  )
}

export default LogoutPage