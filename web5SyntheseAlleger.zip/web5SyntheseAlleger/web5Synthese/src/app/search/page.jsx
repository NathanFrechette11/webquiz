"use client";

import { useState, useEffect } from "react";
import { createClient } from "@/app/_lib/supabase/client";
import { useSearchParams } from "next/navigation";
import ListeQuiz from "../_components/ListeQuiz";
import { recherche } from "../_actions/chercherElement";
import styles from "./page.module.css";

const Search = () => {
  const [quizzes, setQuizzes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const searchParams = useSearchParams();
  const query = searchParams.get("q");

  useEffect(() => {
    const fetchQuizzes = async () => {
      const supabase = createClient();
      setLoading(true);
      try {
        const { data, error } = await supabase
          .from("quizzes")
          .select()
          .ilike("title", `%${query}%`);
        if (error) throw error;
        setQuizzes(data || []);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    if (query) {
      fetchQuizzes();
    }
  }, [query]);

  return (
    <div className={styles.searchpage}>
      <form action={recherche} className={styles.search}>
        <input type="text" name="recherche" className={styles.search__input} />
        <button type="submit" className={styles.search__button}>
          Search 🔍
        </button>
      </form>
      <div>
        <h1 className={styles.searchpage__title}>All quizzes containing: "{query}"</h1>
        {loading && <p>Loading...</p>}
        {error && <p style={{ color: "red" }}>Error: {error}</p>}
        {!loading && !error && (
          <ul>
            <ListeQuiz quizzesInitial={quizzes} />
          </ul>
        )}
      </div>
    </div>
  );
};

export default Search;
