// app/resultat/[score].js

import { createClient } from "@/app/_lib/supabase/server";
import styles from "../../../_components/QuizRetro.module.css";
import Link from "next/link";

// upsert le pourcentage dans la bd et garder la ref
const Resultat = async ({ params }) => {
  const { pourcentage } = await params;

  const supabase = createClient();
  
  const { data: { user } } = await supabase.auth.getUser();

  const { data: profile } = await supabase
    .from('profiles')
    .select()
    .eq('id', user.id)
    .single();

  if(profile.is_banned)
  {
    redirect(`/banned`);
  }

  return (
    <div>
      <div className={styles.QuizRetro__Title_container}>
        <h1 className={styles.QuizRetro__Title}>Quiz results</h1>
      </div>
      <div className={styles.QuizRetro__Container}>
        {pourcentage ? (
          <>
            <p className={styles.QuizRetro__Pourcent}>
              Percentage : {pourcentage}%
            </p>
          </>
        ) : (
          <p>Loading...</p>
        )}
        <Link className={styles.Button} href="/site">
          Back to the quiz list
        </Link>
      </div>
    </div>
  );
};

export default Resultat;
