import { chercherQuizParId } from "@/app/_actions/chercherElement";
import { validerReponses } from "@/app/_actions/envoyerFormulaire";
import MultipleChoice from "@/app/_components/MultipleChoices";
import OneChoice from "@/app/_components/OneChoice";
import TrueFalse from "@/app/_components/TrueFalse";
import Number from "@/app/_components/Number";
import Matching from "@/app/_components/Matching";
import Ordering from "@/app/_components/Ordering";
import { createClient } from "@/app/_lib/supabase/server";
import { redirect } from "next/navigation";
import Link from "next/link";
import QuizRetro from "@/app/_components/QuizRetro";
import ShareQuiz from "@/app/_components/ShareQuiz";
import { getSharedUsers } from "@/app/_actions/shareQuiz";
import { selectProfileAction } from "@/app/_actions/getProfile";
import styles from "../../_components/PlayQuiz.module.css";

const Quiz = async ({ params }) => {
  const { quizId } = params;

  const supabase = createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { data: profile } = await supabase
    .from("profiles")
    .select()
    .eq("id", user.id)
    .single();

  if (profile.is_banned) {
    redirect(`/banned`);
  }

  let totalBonnesReponses = 0;

  const quiz = await chercherQuizParId(quizId);

  if (
    quiz.quizData[0].created_by != user.id &&
    quiz.quizData[0].is_banned == true
  ) {
    redirect(`/site`);
  }

  let retroQuiz = {};

  let isOwner = false;

  const sharedUsersId = await getSharedUsers(quizId);

  const attempts = quiz.attempts;

  const attemptsCount = quiz.attempsCount;

  if (user.id == quiz.quizData[0].created_by) {
    retroQuiz = {
      point_avg: quiz.quizData[0].point_avg,
      attempts: attemptsCount,
    };

    console.log("retroQuiz", retroQuiz);

    isOwner = true;
  }
  const sharedUsers = [];
  for (const element of sharedUsersId) {
    const profile = await selectProfileAction(element.user_id);
    sharedUsers.push(profile.data);
  }

  const ParseOptions = (options) => {
    if (typeof options === "object") {
      return options;
    }

    try {
      return JSON.parse(options);
    } catch (error) {
      console.error("Erreur lors du parsing des options :", error);
      return [];
    }
  };

  const AugmenterBonneReponse = (option) => {
    if (option.isCorrect) {
      totalBonnesReponses = totalBonnesReponses + 1;
    }
  };

  const AfficherQuestion = (
    questionid,
    questiontitle,
    questionimg,
    type,
    optionsArray
  ) => {
    if (quiz.quizData[0].is_banned != true) {
      if (type == "true_false") {
        {
          optionsArray.map((option, index) => {
            {
              AugmenterBonneReponse(option);
            }
          });
        }
        return (
          <TrueFalse
          className={styles.PlayQuiz__questions}
            questionid={questionid}
            questiontitle={questiontitle}
            questionimg={questionimg}
            optionsArray={optionsArray}
          />
        );
      } else if (type == "number") {
        totalBonnesReponses = totalBonnesReponses + 1;
        return (
          <Number
          className={styles.PlayQuiz__questions}
            questionid={questionid}
            questiontitle={questiontitle}
            questionimg={questionimg}
            optionsArray={optionsArray}
          />
        );
      } else if (type == "one_choice") {
        {
          optionsArray.map((option, index) => {
            {
              AugmenterBonneReponse(option);
            }
          });
        }
        return (
          <OneChoice
          className={styles.PlayQuiz__questions}
            questionid={questionid}
            questiontitle={questiontitle}
            questionimg={questionimg}
            optionsArray={optionsArray}
          />
        );
      } else if (type == "multiple_choice") {
        {
          optionsArray.map((option, index) => {
            {
              AugmenterBonneReponse(option);
            }
          });
        }
        return (
          <MultipleChoice
          className={styles.PlayQuiz__questions}
            questionid={questionid}
            questiontitle={questiontitle}
            questionimg={questionimg}
            optionsArray={optionsArray}
          />
        );
      } else if (type == "matching") {
        totalBonnesReponses = totalBonnesReponses + optionsArray.length * 2;
        return (
          <Matching
          className={styles.PlayQuiz__questions}
            questionid={questionid}
            questiontitle={questiontitle}
            questionimg={questionimg}
            optionsArray={optionsArray}
          />
        );
      } else if (type == "ordering") {
        totalBonnesReponses = totalBonnesReponses + optionsArray.length;
        return (
          <Ordering
          className={styles.PlayQuiz__questions}
            questionid={questionid}
            questiontitle={questiontitle}
            questionimg={questionimg}
            optionsArray={optionsArray}
          />
        );
      }
    }
  };

  return (
    <div className={styles.PlayQuiz}>
      <div className={styles.PlayQuiz__infos}>
        <div>
          <h1 className={styles.PlayQuiz__title}>
            {quiz.quizData[0].quiztitle}
          </h1>
          <p>Category: {quiz.quizData[0].name}</p>
        </div>
        <p className={styles.PlayQuiz__descript}>{quiz.quizData[0].quizdesc}</p>
      </div>

      <div>
        {user.id == quiz.quizData[0].created_by && (
          <QuizRetro
            retroQuiz={retroQuiz}
            isOwner={isOwner}
            sharedUsers={sharedUsers}
            quizId={quizId}
          />
        )}

        <ShareQuiz quizId={quizId} />
      </div>


      {!quiz.quizData[0].is_banned && (
        <form action={validerReponses}>
          {quiz.quizData.map(
            ({ questionid, questiontitle, questionimg, type, options }) => {
              const optionsArray = ParseOptions(options);

              return (
                <div key={questionid}>
                  <input type="hidden" name="quiz_id" value={quizId} />
                  {AfficherQuestion(
                    questionid,
                    questiontitle,
                    questionimg,
                    type,
                    optionsArray
                  )}
                </div>
              );
            }
          )}
          <button className={styles.submitButton}>Submit Answers</button>
          <input
            type="hidden"
            name="totalBonneReponses"
            value={totalBonnesReponses}
          />
        </form>
      )}
      {quiz.quizData[0].is_banned && (
        <p>
          This quiz has been banned. Reason for ban :{" "}
          {quiz.quizData[0].desc_banned}
        </p>
      )}
    </div>
  );
};
export default Quiz;
