# Fonctionnalites 

## Luka 
### Partage de questionnaires
Afin de partager le questionnaire, on peut choisir (lorsqu'on est sur la page du quiz) entre un username ou un courriel pour rechercher un utilisateur. Lorsqu'il y aura des utilisateurs d'invites, il y aura une liste des utilisateurs ainsi qu'un bouton pour les retirer de la liste d'utilisateurs qui peuvent y acceder. Ceci peut seulement etre fait si le user est le createur du quiz.

### Recompenses et badges
On accumule les badges en explorant le site et en jouant a des quizs. 
- Se connecter sur le site pour la premiere fois (First connection) -> Le user peut choisir une photo de profil d'une plus grande selection d'images.
- Avoir un score parfait sur un quiz pour la premiere fois (Track record) -> Le user peut modifier son nom d'utilisateur.
- L'utilisateur a joue a son premier quiz (First quiz) -> Le user a acces au changement de photo de profil.
- L'utilisateur change sa photo de profil pour la premiere fois (Mirror mirror...) -> Le user peeut maintenant upload une image de son choix comme photo de profil.

## Nathan
### Options de modération
pour pouvoir acceder a la page des options de modérations, le profil de l'utilisateur doit etre en mode "admin".
pour mettre un profil en mode "admin", ce sont les admins qui peuvent le faire depuis cette page