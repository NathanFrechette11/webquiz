# Taches a faire

## Livrable 2 

### Luka
- fix img adding
- retro (page de quiz -> attempts.count, points_avg) -> middleware -> user.auth == created_by
- profil
- secondaires
- rls policies   (created_by = auth.uid())

### Nathan
- moderation dans la bd
- questionnaire -> isSuspended
- user -> isBlocked
- integrer base sur bools dans l'app
- modules priori
### Hans
- quizs prefaits (debloquable par niveau a faire pour logiques) + bonus xp for incentive